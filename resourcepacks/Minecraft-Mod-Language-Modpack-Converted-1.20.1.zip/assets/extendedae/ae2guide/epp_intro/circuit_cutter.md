---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Circuit Slicer
    icon: extendedae:circuit_cutter
categories:
- extended devices
item_ids:
- extendedae:circuit_cutter
---

# Circuit Slicer

<Row gap="20">
<BlockImage id="extendedae:circuit_cutter" scale="8"></BlockImage>
</Row>

Can't tolerate the slow speed of inscriber? Now we have the Circuit Slicer! They can slice material block into processor 
[prints](ae2:items-blocks-machines/processors.md) directly, so they are 9x faster than inscriber at most time.

**Notice: The glass faces that don't have port can't connect to network.**

